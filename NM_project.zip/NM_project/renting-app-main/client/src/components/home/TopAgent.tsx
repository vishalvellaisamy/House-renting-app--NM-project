import React from "react";

const TopAgent = () => {
    return <div>TopAgent</div>;
};

export default TopAgent;
