import logo from "./logo.svg";
import yariga from "./yariga.svg";

export { logo, yariga };
